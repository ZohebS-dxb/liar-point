const questions = [
  "How many pets do you have?",
  "What’s your favorite meal of the day?",
  "If you could live anywhere, where would it be?",
  "What’s a talent you wish you had?",
  "What’s your guilty pleasure TV show?"
];

export default questions;