import React from 'react';

export default function GamePage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-green-200 text-4xl font-bold">
      Game Page – Under Construction 🚧
    </div>
  );
}
