const raiseYourHandQuestions = [
  "Raise your hand if you’ve ever lied in a game.",
  "Raise your hand if you’ve traveled abroad.",
  "Raise your hand if you’ve pulled an all-nighter.",
  "Raise your hand if you’ve ever sung in public.",
  "Raise your hand if you’ve broken something and not told anyone.",
  "Raise your hand if you’ve ever skipped class.",
  "Raise your hand if you’ve cried during a movie.",
  "Raise your hand if you’ve lost your phone.",
  "Raise your hand if you’ve danced in the rain.",
  "Raise your hand if you’ve tried a weird food combo.",
];

export default raiseYourHandQuestions;