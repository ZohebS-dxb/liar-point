const whosTheImposterFakerPrompt = "You’re the Faker! Guess who fits the bill and don’t get caught.";
export default whosTheImposterFakerPrompt;