const fakerPrompts = [
  "You're the IMPOSTER. Show any random number of fingers from 1 to 10!",
  "You’re the Faker! Bluff with a number.",
  "Act natural – fake a number!",
  "You don’t know the question. Just pick a number!",
  "No clue what's going on? Perfect. Show some fingers!",
  "Wing it. Any number from 1 to 10!",
  "Pretend you understood. Hold up a number!",
  "Guess time! Pick a number. Hope it works!",
  "You’re the secret Faker. Pick wisely.",
  "Look confident and show a number!",
  "Don’t get caught. Hold up a number!",
  "Keep a straight face. Any number from 1 to 10!",
  "Pick a number. Hope they don’t catch you!",
  "Bluff mode ON. Choose a number!",
  "Improvise! Show 1–10 fingers.",
  "You’re the imposter. Choose fast!",
  "Fake it like you mean it.",
  "Smile and pick a number!",
  "Fool them all. Choose a number.",
  "Act smart – show a number!",
  "Faker alert! Fingers up – now!",
  "Don’t panic. Hold up fingers.",
  "Play cool. Pick a random number.",
  "All eyes on you. Pick one!",
  "Quick! Hold up fingers. Act normal."
];

export default fakerPrompts;
