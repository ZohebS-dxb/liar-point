const pointItOutFakerPrompt = "You're the Faker! Just point randomly and act confident.";
export default pointItOutFakerPrompt;