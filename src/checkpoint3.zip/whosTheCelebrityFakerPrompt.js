const whosTheCelebrityFakerPrompt = "You're the Faker! Pretend you know who everyone is speaking about";
export default whosTheCelebrityFakerPrompt;