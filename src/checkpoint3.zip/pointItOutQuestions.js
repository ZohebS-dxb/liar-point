const pointItOutQuestions = [
  "Point to the person most likely to survive a zombie apocalypse.",
  "Point to the best cook in the group.",
  "Point to the person who spends the most time on their phone.",
  "Point to the best dancer here.",
  "Point to the person who’s always late.",
  "Point to the person who tells the best stories.",
  "Point to the person most likely to win a trivia game.",
  "Point to the person who laughs the loudest.",
  "Point to the best dressed right now.",
  "Point to the person who’s most competitive.",
];

export default pointItOutQuestions;