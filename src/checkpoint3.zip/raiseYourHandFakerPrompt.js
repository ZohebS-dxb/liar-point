const raiseYourHandFakerPrompt = "You’re the Faker! Decide if you raise your hand or not. Blend in!";
export default raiseYourHandFakerPrompt;