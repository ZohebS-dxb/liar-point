const whosTheImposterQuestions = [
  "Name a fruit that’s red.",
  "Name a car brand.",
  "Name a superhero.",
  "Name a country in Europe.",
  "Name something you eat with rice.",
  "Name an animal that swims.",
  "Name a city in India.",
  "Name a cartoon character.",
  "Name a famous singer.",
  "Name a mobile app.",
];

export default whosTheImposterQuestions;