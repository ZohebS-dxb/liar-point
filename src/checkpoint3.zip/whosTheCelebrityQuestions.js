const whosTheCelebrityQuestions = [
  "Describe a celebrity without naming them: ‘Wears sunglasses, has a famous laugh.’",
  "Imitate a celebrity and let others guess who it is.",
  "Act like a famous singer performing on stage.",
  "Describe a celebrity known for action films.",
  "Talk like a celebrity known for dramatic roles.",
  "Say a movie quote and let others guess the celebrity.",
  "Act like a celebrity on a talk show.",
  "Do a red carpet walk like a celebrity.",
  "Mimic a celebrity’s dance move.",
  "Describe a celebrity chef while pretending to cook.",
];

export default whosTheCelebrityQuestions;